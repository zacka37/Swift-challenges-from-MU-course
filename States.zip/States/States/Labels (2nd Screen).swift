//
//  Labels (2nd Screen).swift
//  States
//
//  Created by Zack Augustine on 10/26/21.
//

import UIKit

class Labels__2nd_Screen_: UIViewController{

    
    @IBOutlet weak var RankLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var PopLabel: UILabel!
    @IBOutlet weak var Pop2018Label: UILabel!
    @IBOutlet weak var Pop2010Label: UILabel!
    
    @IBOutlet weak var DensityLabel: UILabel!
    
    
    var rank: Int?
    var name: String?
    var pop: Int?
    
    
    var pop2018:Int?
    var pop2010:Int?
    var density:Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        guard let rank = rank.self, let pop = pop.self, let pop2018 = pop2018.self, let pop2010 = pop2010.self, let density = density.self else {
            return
        }
        
        let rankString: String = String(rank)
        let popString: String = String(pop)
        let pop2018String: String = String(pop2018)
        let pop2010String: String = String(pop2010)
        let densityString: String = String(density)
        
        RankLabel.text = rankString
        NameLabel.text = name
        PopLabel.text = popString
        Pop2018Label.text = pop2010String
        Pop2010Label.text = pop2018String
        DensityLabel.text = densityString
        
        
        
        
        
        
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
