//
//  Tip.swift
//  Trekr
//
//  Created by Zack Augustine on 8/31/21.
//

import Foundation

struct Tip: Decodable {
    let text: String
    let children: [Tip]?
    
}
